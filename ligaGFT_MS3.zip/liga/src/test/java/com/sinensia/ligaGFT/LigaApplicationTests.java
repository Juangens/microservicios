package com.sinensia.ligaGFT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LigaApplicationTests {

	@Test
	void contextLoads() {
	}

}
