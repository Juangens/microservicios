package com.sinensia.ligaGFT.business.model;

import lombok.Data;

@Data
public class Equipo {

	private Long id;
	private String nombre;
}
