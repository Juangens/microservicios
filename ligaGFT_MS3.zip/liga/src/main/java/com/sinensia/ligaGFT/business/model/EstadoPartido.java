package com.sinensia.ligaGFT.business.model;

public enum EstadoPartido {
	PENDIENTE, PRIMERA_PARTE, DESCANSO, SEGUNDA_PARTE, FINALIZADO;
}
