package com.sinensia.ligaGFT.business.services;

import com.sinensia.ligaGFT.business.model.Equipo;

public interface EquipoService {
	public Equipo getEquipoById(Long id);
}
