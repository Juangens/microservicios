package com.sinensia.ligaGFT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LigaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LigaApplication.class, args);
	}

}
