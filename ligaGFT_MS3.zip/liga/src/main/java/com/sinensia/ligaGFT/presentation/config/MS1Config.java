package com.sinensia.ligaGFT.presentation.config;

public class MS1Config {

	public static final String NODE_URL = "http://10.250.9.2:8090";

}
